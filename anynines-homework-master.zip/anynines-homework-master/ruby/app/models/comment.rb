class Comment < ActiveRecord::Base 
  self.table_name = 'comments'
end
