class Article < ActiveRecord::Base 
  self.table_name = 'articles'
end
