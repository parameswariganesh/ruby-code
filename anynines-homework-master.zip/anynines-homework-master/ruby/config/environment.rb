require 'dotenv'

Dotenv.load "#{__dir__}/.env"
