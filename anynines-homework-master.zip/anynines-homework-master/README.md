# Anynines Applicant Homework 

This repository contains two kinds of homework for applicants.

## Bosh Homework

Template for a bosh based homework.

## Ruby App Homework

Template for a ruby app homework.
